import React from "react";
const Team =()=>{
    return(
        <div>
            <p>This is Team Functional Component</p>
        </div>
    );
};
export default Team;