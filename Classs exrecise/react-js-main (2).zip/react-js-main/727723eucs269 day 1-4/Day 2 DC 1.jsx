const Tesla=()=>{
    return (
        <><h1 style={{ display: 'flex',
            flexDirection: 'column', 
            alignItems: 'center',
            justifyContent: 'center',
            textAlign: 'center'}}>Car and Location Info</h1>
        <div style={{border:'1px solid black', display: 'flex',
        flexDirection: 'column', 
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        margin:'0 500px'}}>
            <h1 style={{color:'grey'}}>Tesla Model S</h1>
            <img src="https://img.freepik.com/free-photo/electric-car-charging-station-isolated-white-background_123827-29018.jpg?t=st=1722960105~exp=1722963705~hmac=1b18c643224afa4fb7b0b372a68eb02a7b3502757deb218161900ea66001e7d4&w=1060" style={{width:'320px',height:'200px'}}/></div>

            <div style={{border:'1px solid black', display: 'flex',
        flexDirection: 'column', 
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        margin:'0 500px',marginTop:'20px'}}>
           <h1 style={{color:'grey'}}>Tesla</h1>
           <p>Palo Alto</p>
        </div>
        </>
    )
}
export default Tesla;