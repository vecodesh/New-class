function Hello(){
    return (
        <div>
            <h1>Hello World</h1>
        </div>
    )
}

export default Hello;
