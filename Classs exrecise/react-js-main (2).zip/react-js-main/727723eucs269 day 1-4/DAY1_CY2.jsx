
function array(){
    let arr1=["North","West","East","South"];
    alert(arr1);
}

function Appii(){
    return(
        <div className="App">
            <button onClick={array}>array</button> 
        </div>
    )
}
export default Appii;